<template>
    
    <div>
      <h2 style="text-align: left;line-height:40px;margin-left:15px;">MV推荐</h2>
      <el-divider></el-divider>
           <div>
      
    </div>
    <el-row :gutter="20" style="margin: auto">
      <el-col :span="8" v-for="(item, index) in results" style="margin-top:30px" :key="index">
        <router-link :to="{name:'Djfsxq', params:{id:item.id} }">
          <div class="grid-content bg-purple" style="border-radius:20px;">
            <img style="width: 100%;height:200px;border-radius:20px;"  :src="item.cover"  />
            <h5 style="text-align: left;margin-left:15px">{{ item.name }}<br>{{item.artistName}}</h5>
          </div>
        </router-link></el-col
      >
    </el-row>
    </div>
</template>

<script>
export default {
  name: "Djfs",
  data() {
    return {
      results: null,
    };
  },
  mounted() {
    this.getDjfs();
  },
  methods: {
    getDjfs() {
      this.$axios({
        url: "http://localhost:3000/mv/first?limit=18",
      }).then((res) => {
          console.log(res.data.data);
        this.results = res.data.data;
      });
    },
  },
};
</script>
<style>

</style>