<template>
	<div>
	<div style="height: 40px;">
		  <!-- <span>{{this.$store.state.isLogin}}</span> -->
		  <!-- <button @click="foo">修改 isLogin</button> -->
    <Tags></Tags></div>
	<div >
	<Rmgd></Rmgd></div>
	</div>
</template>
<script>
	import Tags from "@/components/Tags.vue"
	import Rmgd from "@/components/Rmgd.vue"
export default {
	name:'Gedan',
	data(){
		return{
			
		}
	},
	methods:{
		foo(){
			this.$store.commit('setLogin')
		}
	},
    components:{
		Tags,
		Rmgd
	}
	
}
</script>
<style lang="scss" scoped>

</style>