<template>
	<div class="home">
		<div class="nav">
		<dl >
			<dd >
				<router-link to="/Tuijian">推荐音乐</router-link>
			</dd>
			<dd >
				<router-link to="/Gedan">歌单</router-link>
			</dd>
			<dd>
				<router-link to="/Phb">排行榜</router-link>
			</dd>
			<dd>
				<router-link to="/Geshou">歌手</router-link>
			</dd>
			<dd>
				<router-link to="/Zxyyxq">最新音乐</router-link></dd>

		</dl>
		 
		</div>
		<el-divider></el-divider>
		<div>
			<router-view class="name"></router-view>
		</div>

	</div>

</template>

<script>

	// @ is an alias to /src
	import HelloWorld from "@/components/HelloWorld.vue";

	export default {
		name: "Home",
		components: {},
	};
 


</script>
<style lang="scss" scoped>
 
	dl {
		width: 70%;
		margin: auto;
		display: flex;
		height: 40px;

		dd {
			flex: 1;
		
	   	height: 60px;

			text-align: center;
			line-height: 60px;
			
		}

		.active {}
	}
.home{
		
}
	a {
		text-decoration: none;
		color: inherit;
	}
	.nav dd:hover{
				cursor: pointer;
				border-bottom:2px solid #109dff;
			}
			.active{
				border-bottom:2px solid #109dff;
			}
			

</style>
