<template>
  <div>
      <Banner/>
  </div>
 
</template>

<script>


import Banner from "./components/Banner.vue"

export default {
    name: "Smview",
      components:{
        Banner
            
           
       
    }
}
</script>
<style lang="scss" scoped>

</style>