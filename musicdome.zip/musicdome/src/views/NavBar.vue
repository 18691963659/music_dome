<template>
      <div>
       <div class="navleft">
        <dl>
          <dt class="title">推荐</dt>

          <dd>
            <i class="el-icon-eleme"></i>
            <router-link to="/Tuijian">发现音乐</router-link>
          </dd>
          <dd>
            <i class="el-icon-s-custom el-icon-video-camera-solid"></i>
            <router-link to="/fm">推荐视频</router-link>
          </dd>
          <dd>
            <i class="el-icon-s-custom"></i>
            <router-link to="/gedan">更多歌单</router-link>
          </dd>
          <dd>
            <i class="el-icon-s-platform"></i>
            <router-link to="/Phb">排行榜</router-link>
          </dd>
          <dd>
            <i class="el-icon-user"></i>
            <router-link to="/Geshou">歌手</router-link>
          </dd>
          <dd>
            <i class="el-icon-video-play"></i>
            <router-link to="/Zxyyxq">最新音乐</router-link>
          </dd>
          
        </dl>
        
      </div>
    </div>
</template>

<script>
export default {
    
}
</script>
<style lang="scss" scoped>
.navleft{
    text-align: left;
   a{color: #000;
   text-decoration: none;
   margin: auto;
 
  
   }  dd{  line-height: 40px;
    text-indent: 10px;
     height: 40px;
     margin: auto;
 
      &:hover{
       background-color:#4fb3fa;
   }
   }
  
}
</style>