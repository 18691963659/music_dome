<template>
	<div>
	<Banner></Banner>
	<Tjgd></Tjgd>
	<Djfs></Djfs>
	<Zxyy></Zxyy>
	</div>
</template>

<script>
	import Banner from '@/components/Banner.vue'
	import Tjgd from '@/components/Tjgd.vue'
	import Djfs from '@/components/Djfs.vue'
	import Zxyy from '@/components/Zxyy.vue'
	export default{
		name:'Tuijian',	
		data(){
			return{
				
			}
		},
		methods:{
			
		},
		components:{
			Banner,
			Tjgd,
			Djfs,
			Zxyy
		}
	}
</script>

<style>
</style>
