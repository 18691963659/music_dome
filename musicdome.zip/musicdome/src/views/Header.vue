<template>
  <dl class="top">
    <dd style="line-height:60px;font-size:18px">(◕ᴗ◕✿)音乐平台</dd>
    <dd>
      <el-input
      
        v-model="input"
        placeholder="请输入内容"
        style="width: 300px;line-height:60px "
      ></el-input>
      <el-button icon="el-icon-search" circle></el-button>
    </dd>
    <dd class="denglu" style="line-height:60px;">
      
      <div v-if="!this.$store.state.isLogin"  @click="dialogVisible = true">未登录</div>
      <div else ="getLogin"><img style="width: 40px; margin-top: 8px;margin-right: 8px;height: 40px;border-radius: 25px;display:inline;float:left" :src="touxiang"  alt="">{{getNickName()}}</div>
      <!-- <span>{{isLogin}}--{{num}}</span> -->
   
    <el-dialog
      title="用户登录"
      :visible.sync="dialogVisible"
      width="30%"
     
    >
      <span slot="footer" class="dialog-footer">
        <el-form
          ref="ruleForm"
          :model="ruleForm"
          :rules="rules"
          label-width="80px"
          class="login-box"
        >
          <el-form-item label="手机号" prop="tel">
            <el-input t placeholder="请输入手机号" v-model="ruleForm.tel" ></el-input>
          </el-form-item>
          <el-form-item label="密码" prop="pass">
            <el-input
              type="password"
              placeholder="请输入密码"
              v-model="ruleForm.pass"
            ></el-input>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" @click="resetForm('ruleFrom')"
              >取 消</el-button
            >
            <el-button @click="submitForm('ruleForm')">登录</el-button>
          </el-form-item>
        </el-form>
      </span>
    </el-dialog>
     </dd>
  </dl>
  
</template>
<script>
import { mapState,mapGetters,mapActions,mapMutations } from "vuex";
export default {
  name: "Header",
  data() {
    return {
      input: "",
      dialogVisible: false,
      restaurants: [],
      touxiang:'',
      state: "",
      ruleForm: {
        tel: "",
        pass: "",
      },

      // 表单验证，需要在 el-form-item 元素中增加 prop 属性
      rules: {
        tel: [
          { required: true, message: "请输入手机号", trigger: "blur" },
          { min: 11, max: 11, message: "手机号格式错误", trigger: "blur" },
        ],
        pass: [
          { required: true, message: "请输入密码", trigger: "blur" },
          { min: 6, max: 12, message: "6-12个字符", trigger: "blur" },
        ],
      },

      // 对话框显示和隐藏
      dialogVisible: false,
    };
  },

  computed: {
    // ...mapState(["isLogin", "num"]),
  },

  methods: {
    ...mapGetters(['getNickName','getLogin']),
    ...mapGetters(['getNickpic','getLogin']),
    ...mapActions(['syncNikeName']),
    ...mapActions(['syncNikepic']),
    resetForm(formName) {
      this.dialogVisible = false;
      this.$refs[formName].resetFields();
    },
    submitForm(formName) {
      // 为表单绑定验证功能
      this.$refs[formName].validate((valid) => {
        if (valid) {
          // 使用 vue-router 路由到指定页面，该方式称之为编程式导航
          console.log(this.ruleForm);
          this.$axios({
            url:
              'http://localhost:3000/login/cellphone?phone='+this.ruleForm.tel+"&password="+this.ruleForm.pass,
            withCredentials: true
          }).then(res => {
            this.touxiang=res.data.profile.avatarUrl;
            console.log(res.data.profile);
            this.syncNikeName(res.data.profile.nickname);
            this.syncNikepic(res.data.profile.avatarUrl);
            console.log(res.data.profile.avatarUrl)
            console.log(this.getNickName());
            console.log(this.getNickpic());
            
          });
        } else {
          console.log("error submit!!");
          return false;
        }
      });
    },

    //       submitForm(fromName){
    // this.$refs[fromName].validate((valid)=>{
    //   id(valid){
    //     console.log('error submit!!');
    //     return false;
    //   }
    // })
    //       },
  },
};
</script>
<style lang="scss" scoped>
* {
  margin: 0;
  padding: 0;
}
.top {
background-color: white;
height: 60px;

  display: flex;
  justify-content: space-around;
 

}
</style>