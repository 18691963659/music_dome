<template>
	<div>
	<h2 style="text-align: left;margin-left:10px">推荐歌单</h2>
	  <el-divider></el-divider>
	<div style="height:500px;"> 
	  <el-row :gutter="10" style="margin: auto; ">
	    <el-col :span="4" v-for="(item,index) in results" :key="index">
				<router-link :to="{name:'Gedanxq',params:{id:item.id}}">
			<div class="grid-content bg-purple" style=" width:90%;margin-left:10px; height: 180px;margin-top: 50px;border-radius:20px;"><img style=" width: 100%;border-radius:20px;" :src="item.picUrl"/>
			<h5 class="wz" style="font-size: 1px; text-align: left;">{{item.name}}</h5>
			</div>
			</router-link></el-col>
	   
	  </el-row>
	</div> 
</div>
</template>

<script>
	export default{
		name:'Tjgd',
		data(){
			return{
			results:null,	
			
		};
	},
	mounted(){
		this.getTjgd();
	},
	methods:{
		getTjgd(){
			this.$axios({
				
				url:"http://localhost:3000/personalized",
				params:{
					limit:12
				}
			}).then((res)=>{
				this.results=res.data.result;
			});
		}
},
};
</script>

<style>
*{

}
  .el-row {
    margin-bottom: 20px;

  }
  .el-col {
    border-radius: 4px;
  }
  .bg-purple-dark {
    background: #99a9bf;
  }
  .bg-purple {
    background: #d3dce6;
  }
  .bg-purple-light {
    background: #e5e9f2;
  }
  .grid-content {
    border-radius: 4px;
    min-height: 36px;
  }
  .row-bg {
    padding: 10px 0;
    background-color: #f9fafc;
  }
  a{
	text-decoration: none;
	color: black;  
  }
</style>
