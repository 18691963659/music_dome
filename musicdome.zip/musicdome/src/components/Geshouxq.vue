<template>
  <div>
    <!-- <h1>{{ this.$route.params.id }}</h1> -->
    <div>
      <div class="top-wrap" style="height: 200px">
        <div class="img-wrap">
          <img
            :src="artist.cover"
            alt=""
            style="width: 200px; height: 200px; float: left; margin-left: 100px"
          />
        </div>
        <div class="info-wrap">
          <h3 style="width: 800px">歌手:{{ artist.name }}</h3>
          <h3 style="width: 800px">单曲数:{{ artist.musicSize }}</h3>
          <h3 style="width: 800px">专辑数:{{ artist.albumSize }}</h3>
          <h3 style="width: 800px">MV数:{{ artist.mvSize }}</h3>
        </div>
      
      </div>

      <br>
      <br>

      <el-row>
        <el-col :span="4" :offset="2">
          <el-image
            :src="gshot[0].al.picUrl"
            style="width: 150px; height: 150px"
            
          ></el-image>
        </el-col>

        <el-col :span="8">
          热门50曲
          <el-table
            :data="gshot"
            highlight-current-row
            stripe
            :show-header="true"
           v-on:row-dblclick="gqid"
            style="
              margin-top: 15px;
              cursor: context-menu;
              border: 1px solid rgb(230, 230, 230);
            "
          >
            <el-table-column label="音乐标题" prop="name"></el-table-column>

            <el-table-column
              label="时长"
              prop="dt"
              width="80px;"
            ></el-table-column>
          </el-table>
        </el-col>
      </el-row>
      
    </div>
   <div class="vue_aplayer">
	  <div class="kb"></div>
    <aplayer
      autoplay
    
      :music="{
    narrow: false,
      /*自动播放，默认值为false，true为开启自动播放*/
      autoplay: true,
      showlrc: true,
      /*lrc歌词显示方式,默认值为1,HTML显示方式，2为JavaScript字符串显示方式，3为lrc文件加载显示方式*/
      lrcType: 3,
      /*主题颜色*/
      theme: '#00b5ad',
      /*歌曲集合列表*/
        title: uuname,
        artist: uuuname,
        src:
          'https://music.163.com/song/media/outer/url?id='+urlid,
        pic: picss
      }"
    />
  </div>
  </div>

  
</template>

<script>

import aplayer from "vue-aplayer";
import Bus from "@/bus/Bus.js";
import axios from "axios";
export default {
   name: "VueAplayer",
  components: {
    aplayer,
  },
  data() {
    return {
      artist: "",
      artists: [],
      gshot: [],
        uuname:"",
      td: "",
      uuuname:"",
      tracks: [],
      playlist: "",
      playlists: "",
      tableData: "",
      tags: "",
      createTime: "",
      songurl: "",
      urlid:"",
      urls:"",
      tracksid: {
        id: "",
        al: {
          name: "",
        },
      },
    };
    
  },

  mounted() {},
  created() {
    this.getartist();

    this.getgshot();
  },

  methods: {
     gqid(row) {
      console.log(row)
      console.log(row.id);
      this.urls=row;
      this.picss=row.al.picUrl;
     this.urlid=row.id;
     this.uuname=row.name;
     this.uuuname=row.al.name;},

    getartist() {
      this.$axios({
        url: "http://localhost:3000/artist/detail?id=" + this.$route.params.id,
      }).then((res) => {
        this.artist = res.data.data.artist;
        // console.log(res.data.data.artist)
      });
    },
    getgshot() {
      this.$axios({
        url:
          "http://localhost:3000/artist/top/song?id=" + this.$route.params.id,
      }).then((res) => {
        
        this.gshot = res.data.songs;
         this.gshot.forEach((item) => {
          const dt = new Date(item.dt);
          const mm = (dt.getMinutes() + "").padStart(2, "0");
          const ss = (dt.getSeconds() + "").padStart(2, "0");

          item.dt = mm + ":" + ss;
        });
        console.log(res.data.songs);
      });
    },

    foo(id) {
      console.log(id);
    },
    getId(id) {
      Bus.$emit("tagId", id);
      //   console.log(id);
    },
  },
};
</script>

<style>
.music {
  width: 100%;
}

.music table {
  width: 100%;
}

.music thead {
  color: #828385;
}

.music tr {
  height: 30px;
  text-align: left;
}

.music tr:hover {
  background-color: #2c2e32;
  color: #fff;
}

.music tr td {
  border: 1px solid #23262c;
  position: relative;
}

.music tbody {
  font-size: 13px;
  color: #575757;
}

.music tr td:nth-child(1) {
  width: 50px;
  text-align: center;
}

.music tr td:nth-child(2) {
  width: 80px;
}

.music tr td:nth-child(2) img {
  width: 20px;
  opacity: 0.6;
}

.music tbody tr td:nth-child(3) {
  white-space: nowrap;
  text-overflow: ellipsis;
  overflow: hidden;
  color: #dcdde4;
}

.music tr td .live {
  position: absolute;
  left: 0;
  top: 0;
  bottom: 0;
  margin: auto;
}

.music tr td .xiazai {
  margin-left: 26px;
}

.music tr td:nth-child(4) {
  width: 140px;
  white-space: nowrap;
  text-overflow: ellipsis;
  overflow: hidden;
}

.music tr td:nth-child(5) {
  width: 180px;
}

.music tr td:nth-child(6) {
  width: 80px;
}

.music tbody tr td {
  border: none;
}

.backColor {
  background: #1a1c20;
}

.el-row {
  margin-bottom: 20px;
}

.el-col {
  border-radius: 4px;
}

.bg-purple-dark {
  background: #99a9bf;
}

.bg-purple {
  background: #d3dce6;
}

.bg-purple-light {
  background: #e5e9f2;
}

.grid-content {
  border-radius: 4px;
  min-height: 36px;
}

.row-bg {
  padding: 10px 0;
  background-color: #f9fafc;
}
.vue_aplayer {

  position: fixed;

  bottom: 0px;
  width: 83%;

  overflow: hidden;
}
</style>
