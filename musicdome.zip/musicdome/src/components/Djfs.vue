<template>
  <div>
    <div >
      <h2 style="text-align: left ;margin-left:10px;margin-top:20px">独家放送</h2>
      <el-divider></el-divider>
    </div>
    <el-row :gutter="20" style="margin: auto">
      <el-col :span="8" v-for="(item, index) in results" :key="index">
        <router-link :to="{name:'Djfsxq', params:{id:item.id} }">
          <div class="grid-content bg-purple" style="border-radius:20px; height:210px">
            <img style="width: 100%;border-radius:20px;" :src="item.picUrl" />
            <p style="text-align: left">{{ item.name }}</p>
          </div>
        </router-link></el-col
      >
    </el-row>
  </div>
</template>

<script>
export default {
  name: "Djfs",
  data() {
    return {
      results: null,
    };
  },
  mounted() {
    this.getDjfs();
  },
  methods: {
    getDjfs() {
      this.$axios({
        url: "http://localhost:3000/personalized/privatecontent",
      }).then((res) => {
        this.results = res.data.result;
      });
    },
  },
};
</script>

<style>

</style>
