<template>
  <div>
    <el-row
      :gutter="10"
      style="margin: auto"
      v-loading="loading"
      element-loading-text="拼命加载中"
      element-loading-spinner="el-icon-loading"
      element-loading-background="rgba(0, 0, 0, 0.8)"
    >
      <el-col :span="4" v-for="(item, index) in playlists" :key="index">
        <router-link :to="{ name: 'Gedanxq', params: { id: item.id } }">
          <div
            class="grid-content bg-purple"
            style="width: 90%; height: 180px; margin-top: 40px;margin-left:10px;border-radius:20px;"
          >
            <img style="width: 100%;border-radius:20px;" :src="item.coverImgUrl" />
            <h5 class="wz" style="font-size: 1px; text-align: left;">
              {{ item.name }}
            </h5>
          </div>
        </router-link>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import Bus from "@/bus/Bus.js";
export default {
  data() {
    return {
      loading: true,
      playlists: [],
    };
  },
  mounted() {
    this.getRm();
    Bus.$on("tagId", (value) => {
      this.loading = true;
      this.$axios({
        url: "http://localhost:3000/top/playlist?cat=" + value,
      }).then((res) => {
        // console.log(res);
        this.playlists = res.data.playlists;
        this.loading = false;
      });
    });
  },
  methods: {
    getRm() {
      this.loading = true;
      this.$axios({
        url: "http://localhost:3000/top/playlist?order=hot",
        // method:'get',
        // params:{
        // 	limit: 10,
        // 	offset,
        // 	cat

        // },
      }).then((res) => {
        // console.log(res);
        this.playlists = res.data.playlists;
        this.loading = false;
      });
    },
  },
};
</script>

<style>
a {
  text-decoration: none;
  color: black;
}
</style>
