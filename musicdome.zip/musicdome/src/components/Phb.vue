6<template>
	<div style="margin-bottom: 55px;">

		<h2 style="text-align: left;margin-left:10px;margin-top:20px">排行榜</h2>
		  <el-divider></el-divider>

		<el-row style="margin-top: 25px;">
			<el-col :span="8" v-for="item in 4" style="margin-top: 25px;">

				<el-image :src="PhbList[item-1].coverImgUrl" style="height: 200px;border-radius: 15px; width: 350px;"></el-image>

				<el-table :data="PhbList[item-1].tracks" stripe :show-header="false">
					<el-table-column type="index">

						<template scope="scope">
							<!-- scope.$index是拿到每一行的index -->
							<span style="color: red;font-weight: 400">{{scope.$index+1}}</span>
						</template>
					</el-table-column>
					<el-table-column prop="first"></el-table-column>
					<el-table-column>
						<template scope="scope">
							<!-- 		scope.row.second 是取该行数据 -->
							<span>{{scope.row.second}}</span>
						</template>
					</el-table-column>
				</el-table>

			</el-col>


		</el-row>


		<h2 style="text-align: left;margin-left:10px;margin-top:20px">排行榜</h2>
		  <el-divider></el-divider>

		<el-row :gutter="4" style="margin-top: 40px;">

			<el-col :span="4" v-for="(item,index) in PhbList" style="margin-top: 10px; position:relative;" :key="index">
				<router-link :to="{name:'Gedanxq',params:{id:item.id}}" style="text-decoration: none; color:  palevioletred;">

					<div>
						<el-image :src="item.coverImgUrl" style="border-radius: 20px; width:180px">
						</el-image>
					</div>
					<h4>{{item.name}}</h4>
				</router-link>
			</el-col>

		</el-row>
	</div>
</template>

<script>
	export default {
		data() {
			return {
				//排行榜的所有数据
				PhbList: [{
						coverImgUrl: ''
					},
					{
						coverImgUrl: ''
					},
					{
						coverImgUrl: ''
					},
					{
						coverImgUrl: ''
					}
				],

			}
		},
		created() {
			//获取官方榜单的数据
			this.Phbsj()
		},
		methods: {
			//获得官方榜单的数据
			Phbsj() {
				this.$axios({
					url: "http://localhost:3000/toplist/detail"
				}).then((res) => {
					console.log(res)
					this.PhbList = res.data.list

				})
			},


		}
	}
</script>

<style scoped>

</style>
