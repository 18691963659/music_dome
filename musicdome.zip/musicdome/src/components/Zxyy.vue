<template>
	<div class="newSongs">
		<h2 style="text-align: left;margin-left:10px;margin-top:20px">最新音乐</h2>
		  <el-divider></el-divider>
	 <div class="content">
	    <div class="item" v-for="(item,index) in newsong" :key="index">
	        <div class="number">{{index+1}}</div>
	        <div class="title">
	          <img :src="item.picUrl"  />
	       
	        </div>
	        <div class="mess">
	          <div style="font-size: 20px; text-align: left;">{{item.name}}</div>
	          <br />
	          <div class="bottom" style="font-size: 15px; ">{{item.song.album.company}}</div>
	        </div>
			</div>
			</div>
	
	  
	</div>
</template>

<script>
	export default{
		name:'Zxyy',
		data(){
			return{
				newsong:null,
			};
		},
		mounted(){
			this.getZxyy();
		},
		methods:{
			getZxyy(){
				this.$axios({
					url:"http://localhost:3000/personalized/newsong",
					
				}).then((res)=>{
					// console.log(res.data.result);
					this.newsong=res.data.result;
				})
			}
		}
	}
</script>

<style>
	.content {
	  width: 100%;
	  display: flex;
	  flex-wrap: wrap;
	}
	.item {
	  padding: 10px 10px;
	  width: 45%;
	  height: 70px;
	  display: flex;
	}
	.number {
	  height: 70px;
	  width: 40px;
	  text-align: center;
	  line-height: 70px;
	}
	.title {
	  position: relative;
	  height: 100%;
	}
	.title img {
	  height: 100%;
	}
	.icon {
	  background: rgba(00, 0, 0, 0.3);
	  border-radius: 50%;
	  width: 18px;
	  height: 18px;
	  position: absolute;
	  left: 0px;
	  right: 0;
	  top: 0;
	  bottom: 0;
	  margin: auto;
	}
	.icon img {
	  width: 100%;
	}
	.mess {
	  flex: 1;
	  margin-left: 10px;
	  font-size: 13px;
	  position: relative;
	}
	.mess .bottom {
	  position: absolute;
	  bottom: 0px;
	}
</style>
