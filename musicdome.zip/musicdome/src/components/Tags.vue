<template>
	<div style="float: left;">
		<span style="text-align: left;margin-left:20px">热门标签:</span>
		<el-tag class="biaoqian" style="font-size: 15px;border-radius:20px;margin-left: 15px;cursor:pointer" v-for="(item,index) in tags" :key="index" @click="getId(item.name)">
			{{item.name}}
		</el-tag>
	</div>
</template>

<script>
	import Bus from '@/bus/Bus.js'
	export default {
		data() {
			return {
				tags: ''
			}
		},
		methods: {
			getId(id){
				console.log(id);
				Bus.$emit('tagId',id)
			},
			getTags() {
				this.$axios({
					url: 'http://localhost:3000/playlist/hot'
				}).then(res => {
					// console.log(res.data.tags);
					this.tags = res.data.tags;
				})
			}
		},
		mounted() {
			this.getTags();
		}
	}
</script>

<style>
</style>
