<template>
    <div class="bj">
    <template>
      <el-carousel :interval="4000" type="card" height="200px">
        <el-carousel-item v-for="(item, index) in banners" :key="index">
          <el-image :src="item.imageUrl"></el-image>
        </el-carousel-item>
      </el-carousel>
    </template>

    </div>
</template>
<script>


export default {
  name:"Banner",
  data(){
	  return{
		  banners:null,
	  };
  },
  mounted(){
	  this.getBanners();
  },
  methods:{
	  getBanners(){
		  this.$axios({
			  url:"http://localhost:3000/banner?type=0",
			  
			  
		  }).then((res)=>{
		
			  this.banners=res.data.banners;
		  });
	  }
  }
}
</script>
<style>

  .el-carousel__item h3 {
    color: #e3e5e9;
    font-size: 14px;
    opacity: 0.75;
    line-height: 200px;
    margin: 0;
   
  }
  
  .el-carousel__item:nth-child(2n) {
    background-color: #99a9bf;
  }
  
  .el-carousel__item:nth-child(2n+1) {
    background-color: #d3dce6;
  }
</style>