<template>
  <div class="vue_aplayer">
	  <!-- <div class="kb"></div>
    <aplayer
      autoplay
      :music="{
        title: '歌曲标题',
        artist: '{{ $id }}',
        src:
          'https://music.163.com/song/media/outer/url?id=1450630238.mp3',
        pic: '歌曲播放器封面url',
      }"
    /> -->
  </div>
</template>

<script>

import Bus from "@/bus/Bus2.js";
import aplayer from "vue-aplayer";
export default {
  name: "VueAplayer",
  components: {
    aplayer,
  },
 
  	// mounted() {
		
		// 	this.Bus2.$on('bfgq', (val) => {
		// 		console.log(val);
		// 		// this.$axios({
		// 		// 	url: 'https://music.163.com/song/media/outer/url?id=${id}'
		// 		// }).then(res => {
		// 		// 	 console.log(res);
		// 		// 	// this.playlists = res.data.playlists;
			
		// 		// })
		// 	})
		// },
  methods:{
	  getbofang(){
		  this.$axios({
			  url:"http://localhost:3000/playlist/detail?id="+this.$route.params.id,
		  }).then(res=>{
			  console.log(res)
		  })
	  }
  }
};
</script>
<style scoped>
.vue_aplayer {

  position: fixed;

  bottom: 0px;
  width: 100%;
  overflow: hidden;
}

</style>