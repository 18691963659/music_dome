<template>
  <div class="One">
    <div class="left">
      <div class="top">
        <h5 class="left-mv">MV</h5>
        <h3 style="margin-left: 10px; margin-top:-5px">{{ title.name }}</h3>
        <h6 style="margin-left: 10px;margin-top:2px">{{ title.artistName }}</h6>
      </div>
<div class="videobian">
      <div class="video" v-if="url != null">
        <video
          :src="url"
          controls
          autoplay
          width="100%"
          class="video-play"
        ></video>
      </div>
</div>

     <div class="pingluns">
        <h3 style="text-align:left; ">精彩评论:</h3>
          <div  v-for="(item, index) in mvpl" :key="index"
                     style="position: relative;border-top: 2px solid rgb(240,240,242);
                 border-bottom: 1px solid rgb(240,240,242);padding: 15px 0;font-size: 15px;">
                    <div>
                        <!--用户头像-->
                        <img :src="item.user.avatarUrl" alt="" style="margin-left:5px;width: 50px;height: 50px;border-radius: 25px;display:inline;float:left">

                        <!--评论信息-->
                        <div style=" text-align: left; ">
                            <p><span style="margin-left:15px;color: #4d99de; text-align: left;">{{item.user.nickname}}</span>: {{item.content}}</p>

                            <p style="margin-left:70px;font-size: 13px;color: gray;opacity: 0.7">{{item.time |formatDate}}</p>
                        </div>
                    </div>
                </div>
      </div>
      
    </div>
    <div class="right">
      <h3 style="text-align: left">MV介绍 {{ this.$route.params.id }}</h3>
      <hr />
      <div style="text-align: right">{{ title.publishTime }}</div>
      <h4 style="text-align: left">介绍:{{ title.desc }}</h4>

      <h3 class="xgtj" style="float: left; padding-top: 20px">相关推荐</h3>
      <div class="simi">
        <div class="simi-item" v-for="(item, index) in simi" :key="index">
          <router-link :to="{ name: 'Djfsxq', params: { id: item.id } }">
            <div class="lefts">
              <img :src="item.cover" alt="" />
              <div class="count">
                <div class="play-count">{{ item.count }}</div>
              </div>
      
            </div>
          </router-link>
          <div class="rights">
            <div class="name">
              <span>MV</span>
              {{ item.name }}
            </div>
            <div class="artist">{{ item.artist }}</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import Bus from "@/bus/Bus.js";
import {formatDate} from '@/date.js'
export default {
  data() {
    return {
      title: "",
      // datas: "",

      Mvurl: "",
      url: "",
      simi: [],
      mvpl: [],
      count: 0,
    };
  },
  filters:{
formatDate(time){
  let date=new Date(time)
  return formatDate(date,'yyyy-MM-dd hh:mm:ss')
}
  },
  created() {
    this.getMVDetailInfo();
    this.getMVDetail();
    this.getsimi();
    this.getmvpl();
  },
  methods: {
    getMVDetailInfo() {
      this.$axios({
        url: "http://localhost:3000/mv/detail?mvid=" + this.$route.params.id,
      }).then((res) => {
        // console.log(res);
        this.title = res.data.data;
        // this.datas = res.data.data;
      });
    },
    load() {
      this.count += 2;
    },
    getsimi() {
      this.$axios({
        url: "http://localhost:3000/simi/mv?mvid=" + this.$route.params.id,
      }).then((res) => {
        this.simi = res.data.mvs;
      });
    },
    getmvpl() {
      this.$axios({
        url: "http://localhost:3000/comment/mv?id=" + this.$route.params.id,
      }).then((res) => {
        this.mvpl = res.data.comments;
        console.log(res.data.comments);
      });
    },

    getMVDetail() {
      this.$axios({
        url: "http://localhost:3000/mv/url?id=" + this.$route.params.id,
      }).then((res) => {
        this.url = res.data.data.url;
        // console.log(res.data.data.url);
      });
    },
  },
  mounted() {
    this.getMVDetail();
  },
};
</script>

<style lang="scss" scoped>
.pinglun {
  margin: auto;
  margin-top: 70px;
  width: 80%;
  height: 600px;
}
.simi {
  width: 100%;
}
.simi-item {
  width: 100%;
  margin-top: 10px;
  display: flex;

}
.pingluns{
  width: 80%;
  margin: auto;

}
.lefts {
  width: 150px;
  position: relative;

}
.touxiang {
  width: 30px;
  height: 30px;
}
.lefts img {
  width: 100%;
}

.lefts .count {
  position: absolute;
  top: 0px;
  right: 0px;
  display: flex;
  align-items: center;
  height: 20px;
  padding: 3px 5px;
  background: rgba(0, 0, 0, 0.25);
}
.lefts .count img {
  height: 100%;
}
.rights {
  flex: 1;
  padding-left: 10px;
}
.rights span {
  padding: 1px;
  color: red;
  font-size: 13px;
  border: 1px solid red;
}
.artist {
  margin-top: 10px;
  font-size: 13px;
  color: var(--color-text-an);
}
.video {
  padding-top: 20px;
  border: black;
  margin: auto;
  width: 80%;
  height: 100px;
}
.One {
  display: flex;
}
.left {
  width: 70%;
  height: 600px;
}
 [class*=el-col-] {
        display: inline-block;
        float: none;
    }

    h1 {
        font-weight: 500;
    }
.right {
  width: 30%;
  height: 600px;
}
.top {
  margin: auto;
  width: 80%;
  font-size: 20px;
  height: 20px;
  display: flex;

  text-align: left;
}
.touxiang {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  margin-right: 15px;
  margin-left: 0;
}
.videobian{
  height: 450px;
  
}
.vid {
  width: 80%;
  margin: auto;
  height: 500px;
  margin-top: 5px;
}
.input_video {
  width: 600px;
  height: 500px;
  margin-top: 30px;
  margin-left: 7a0px;
}
.left-mv {
  border: 2px solid red;
  color: red;
margin-top: auto;
  width: 26px;
  height: 20px;
}
.name {
  float: left;
}
.infinite-list {
  padding-top: 220px;
}
.infinite-list-item {
  img {
    float: left;
 line-height: 7px;

  }
  h3 {
    float: left;
    margin-left: 30px;
      line-height: 7px;
    
  }
  h4 {
    float: left;
    margin-left:2px;
    margin-top: 30px;
    text-align: left;

    width: 380px;
  }
  margin: auto;
  width: 80%;
  height: 80px;
  background-color: lightgray;
  border: 1px solid lightslategray;
  list-style: none;

}
</style>