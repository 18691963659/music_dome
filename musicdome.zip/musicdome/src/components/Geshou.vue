<template>
	<div>
	<div style="height: 40px;">
	
		<GsTags></GsTags>
    </div>

	  <div>
		
    <el-row
      :gutter="10"
      style="margin: auto"
      v-loading="loading"
      element-loading-text="拼命加载中"
      element-loading-spinner="el-icon-loading"
      element-loading-background="rgba(0, 0, 0, 0.8)"
    >
      <el-col :span="4" v-for="(item, index) in dan" :key="index" >
        <router-link :to="{ name: 'Geshouxq', params: { id: item.id } }">
          <div
            class="grid-content bg-purple"
            style="width: 100%; height: 180px; margin-top: 40px;border-radius:20px;"
          >
            <img style="width: 100% ; height:100%;border-radius:20px; " :src="item.picUrl" />
            <h4 class="wz" style=" text-align: center">
              {{ item.name }}
            </h4>
          </div>
        </router-link>
      </el-col>
    </el-row>
  </div>
	</div>
	
	
</template>

<script>
import GsTags from "@/components/GsTags.vue"
	import Bus from '@/bus/Bus.js'
	export default {
		name: 'gstj',

		data() {
			return {
				Geshou:'',
				dan:'',
				loading: true,
			}

		},
		components:{
		GsTags,
	
	},
	
	 mounted() {
		  
    this.getGeshou();
	this.loading = false;
    Bus.$on("tagIds", (value) => {
     this.loading = true;
      this.$axios({
        url: "http://localhost:3000/artist/list?type=-1&area="+ value+"&initial=b",
      }).then((res) => {
        console.log(res);
        this.dan = res.data.artists;
        this.loading = false;
      });
    });
  },
		// mounted(){
  //         this.getGeshou();
		// },
		// created(){
		// 	this.getGeshou();
		// },
		methods: {
			getGeshou() {
				this.$axios({
					url:"http://localhost:3000/top/artists?offset=0&limit=30",
					params: {

					}
				}).then((res) => {
					console.log(res)
					this.dan= res.data.artists
				});
			}
		}
	}
</script>

<style>
	.el-row {
		margin-bottom: 20px;

	
	}

	.el-col {
		border-radius: 4px;
	}

	.bg-purple-dark {
		background: #99a9bf;
	}

	.bg-purple {
		background: #d3dce6;
	}

	.bg-purple-light {
		background: #e5e9f2;
	}

	.grid-content {
		border-radius: 4px;
		min-height: 36px;
	}

	.row-bg {
		padding: 10px 0;
		background-color: #f9fafc;
	}
</style>
