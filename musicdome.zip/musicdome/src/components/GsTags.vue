<template>
	<div style="float: left;">
        <div>
		<span style="text-align: left;margin-left:15px">语种:</span>
		<el-tag class="biaoqian" style="font-size: 15px;border-radius:20px;margin-left: 15px;cursor:pointer;margin-left: 15px;" v-for="(item,index) in area" :key="index" @click="getIds(item.value)">
			{{item.name}}
		</el-tag></div>
        <div>
     
        
        	
      </div>
	</div>
    
</template>

<script>
	import Bus from '@/bus/Bus.js'
	export default {
		data() {
			return {
				
         area: [
        { value: -1, name: "全部" },
        { value: 7, name: "华语" },
        { value: 96, name: "欧美" },
        { value: 8, name: "日本" },
        { value: 16, name: "韩国" },
        { value: 0, name: "其他" }
      ],
       type: [
        { value: -1, name: "全部" },
        { value: 1, name: "男歌手" },
        { value: 2, name: "女歌手" },
        { value: 3, name: "乐队" }
      ]
			}
		},
		methods: {
			getIds(value){
				console.log(value);
				Bus.$emit('tagIds',value)
			},
		
		},
		
	}
</script>

<style>
</style>
