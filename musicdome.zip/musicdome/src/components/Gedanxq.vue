<template>
  <div>
    <div class="top-wrap" style="height: 200px">
      <div class="img-wrap">
        <img
          :src="playlist.coverImgUrl"
          style="width: 200px; height: 200px; float: left; margin-left: 100px"
        />
      </div>
      <div class="info-wrap">
        <h3 style="width: 800px">{{ playlist.name }}</h3>
        <div class="author-wrap" style="width: 800px">
          <img
            class="avatar"
            :src="playlists.avatarUrl"
            style="
              width: 30px;
              height: 30px;
              border-radius: 100%;
              margin-bottom: -7px;
            "
          />
          <span class="name" style="margin-left: 15px">{{
            playlists.nickname
          }}</span
          >&nbsp;
          <span class="time">{{ createTime }} 创建</span>
        </div>
        <div class="tag-wrap" style="width: 585px; margin-top: 60px">
          <span class="title" style="margin: 80px">标签:{{ tags[0] }}</span>
        </div>
        <div class="desc-wrap" style="position: absolute; margin-left: 410px">
          <span class="title">简介:</span>
          <span class="desc" style="text-align: left;">{{ playlists.signature }}</span>
          <span>{{ tracks.id }}</span>
        </div>
      </div>
    </div>
    <!-- {{ this.$route.params.id }} -->
    <el-divider></el-divider>

    <el-table
      :data="tracks"
      ref="playTable"
      highlight-current-row
      border
      stripe
      style="cursor: context-menu"
      v-on:row-dblclick="gqid"
    >
      <el-table-column label="#" type="index">
        <template scope="scope">
          <p>{{ scope.$index + 1 }}</p>
        </template>
      </el-table-column>
      <el-table-column label="音乐标题" prop="name"></el-table-column>

      <el-table-column label="歌手" prop="ar[0].name" width="80px;">
      </el-table-column>

      <el-table-column label="专辑名" prop="al.name"></el-table-column>

      <el-table-column label="时长" prop="dt" width="80px;"></el-table-column>
    </el-table>
    <div class="hh">

    </div>
     <div class="vue_aplayer">
	  <div class="kb"></div>
    <aplayer
      autoplay
    
      :music="{
    narrow: false,
      /*自动播放，默认值为false，true为开启自动播放*/
      autoplay: true,
      showlrc: true,
      /*lrc歌词显示方式,默认值为1,HTML显示方式，2为JavaScript字符串显示方式，3为lrc文件加载显示方式*/
      lrcType: 3,
      /*主题颜色*/
      theme: '#00b5ad',
      /*歌曲集合列表*/
        title: uuname,
        artist: uuuname,
        src:
          'https://music.163.com/song/media/outer/url?id='+urlid,
        pic: picss
      }"
    />
  </div>
  </div>
  
</template>
<script>

import aplayer from "vue-aplayer";
export default {
  name: "VueAplayer",
  components: {
    aplayer,
  },

  data() {
    return {
      uuname:"",
      td: "",
      uuuname:"",
      tracks: [],
      playlist: "",
      playlists: "",
      tableData: "",
      tags: "",
      createTime: "",
      songurl: "",
      urlid:"",
      urls:"",
      tracksid: {
        id: "",
        al: {
          name: "",
        },
      },
    };
  },
  methods: {
    gqid(row) {
      console.log(row)
      console.log(row.id);
      this.urls=row;
      this.picss=row.al.picUrl;
     this.urlid=row.id;
     this.uuname=row.name;
     this.uuuname=row.al.name;
    },

    getDanDetail() {
      this.$axios({
        url:
          "http://localhost:3000/playlist/detail?id=" + this.$route.params.id,
      }).then((res) => {
        // console.log(res.data);
        this.tracks = res.data.playlist.tracks;
        console.log(res.data.playlist);

        //处理时长数据
        this.tracks.forEach((item) => {
          const dt = new Date(item.dt);
          const mm = (dt.getMinutes() + "").padStart(2, "0");
          const ss = (dt.getSeconds() + "").padStart(2, "0");

          item.dt = mm + ":" + ss;
        });
        this.tracksid = res.data.playlist.tracks;
        console.log(res.data.playlist.tracks.id);

        this.playlist = res.data.playlist;
        this.tags = res.data.playlist.tags;
        this.playlists = res.data.playlist.creator;
        this.songurl = res.data.playlist.tracks.id;
      });
    },
  },

  mounted() {
    this.getDanDetail();
    Bus.$on("", (value) => {
      this.tableData();
      this.$axios({
        url: "http://localhost:3000/top/playlist/detail?id=${id}",
      }).then((res) => {
        console.log(res.data.playlists);
        this.playlist = res.data.playlist;
      });
    });
  },
};
</script>
<style lang='scss' scoped>
.top {
  border: 1px solid red;
  height: 300px;
  color: red;
}

.music {
  width: 100%;
}
.hh{

  height: 80px;
}
.music table {
  width: 100%;
}

.music thead {
  color: #828385;
 
}

.music tr {
  height: 30px;
  text-align: left;
}

.music tr:hover {
  background-color: #2c2e32;
  color: #fff;
}

.music tr td {
  border: 1px solid #23262c;
  position: relative;
}

.music tbody {
  font-size: 13px;
  color: #575757;
}

.music tr td:nth-child(1) {
  width: 50px;
  text-align: center;
}

.music tr td:nth-child(2) {
  width: 80px;
}

.music tr td:nth-child(2) img {
  width: 20px;
  opacity: 0.6;
}

.music tbody tr td:nth-child(3) {
  white-space: nowrap;
  text-overflow: ellipsis;
  overflow: hidden;
  color: #dcdde4;
}

.music tr td .live {
  position: absolute;
  left: 0;
  top: 0;
  bottom: 0;
  margin: auto;
}

.music tr td .xiazai {
  margin-left: 26px;
}

.music tr td:nth-child(4) {
  width: 140px;
  white-space: nowrap;
  text-overflow: ellipsis;
  overflow: hidden;
}

.music tr td:nth-child(5) {
  width: 180px;
}

.music tr td:nth-child(6) {
  width: 80px;
}

.music tbody tr td {
  border: none;
}

.backColor {
  background: #1a1c20;
}

.el-row {
  margin-bottom: 20px;
  &:last-child {
    margin-bottom: 0;
  }
}
.el-col {
  border-radius: 4px;
}
.bg-purple-dark {
  background: #99a9bf;
}
.bg-purple {
  background: #d3dce6;
}
.bg-purple-light {
  background: #e5e9f2;
}
.grid-content {
  border-radius: 4px;
  min-height: 36px;
}
.row-bg {
  padding: 10px 0;
  background-color: #f9fafc;
}


.vue_aplayer {

  position: fixed;

  bottom: 0px;
  width: 83%;

  overflow: hidden;
}


</style>

