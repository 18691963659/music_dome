import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    //状态
    //定义全局需要共享的数据
    isLogin: false,
    num: '123',
    nickname: null,
  },
  mutations: {
    //如果需要修改共享数据，要使用mutations中方法来修改

    //修改islogin
    setnickName(state, value) {
      state.nickname = value;
      state.isLogin = true;
    },
    setnickpic(state, value) {
      state.avatarUrl = value;
      state.isLogin = true;
    },
    setLogin(state) {
      state.isLogin = true;

    }
  },
  actions: {
    //异步操作方法
    syncNikeName(context, value) {
      context.commit('setnickName', value)
    },
    syncNikepic(context,value){
      context.commit('setnickpic',value)
    }
  },
  getters: {
    //用于获取状态
    getNickName(state) {
      return state.nickname;
    },
    getNickpic(state) {
      return state.avatarUrl;
    },
    getLogin(state) {
      return state.isLogin;
    }
  },

  modules: {

  }
})
