<template>
	<div id="app">
		<div class="top">
			<Header></Header>
			
		</div>
		<div class="sm">
			<div class="leftnav">
				<NavBar></NavBar>
				
			</div>

			<div class="rightnav">
				
				<router-view></router-view>
				
			</div>
		</div>
		
	<div class="bfq" >
		<Bfq></Bfq>
	</div>
	</div>
	
</template>
<script>
	import Bfq from "@/components/Bfq.vue";
	import NavBar from "./views/NavBar.vue";
	import Header from "./views/Header.vue";
	import Tuijian from "./views/Tuijian.vue";
	export default {
		name: "app",
		components: {
			Header,
			NavBar,
			Bfq,
			Tuijian
		},
	};
</script>
<style lang="scss">
	#app {
		font-family: Avenir, Helvetica, Arial, sans-serif;
		-webkit-font-smoothing: antialiased;
		-moz-osx-font-smoothing: grayscale;
		text-align: center;
		color: #2c3e50;
		
	}
*{
	margin: 0;
	padding: 0;
}
	.sm {
		display: flex;
	}

	.leftnav {
		
	background-color:white;
		width: 20%;
	}

	.rightnav {

		width: 100%;
	}
</style>
