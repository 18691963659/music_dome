import Vue from 'vue'
import VueRouter from 'vue-router'

import Home from '../views/Home.vue'

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'Home',
    component: Home,
    children: [
     {
		name:'Tuijian',
		path:'/Tuijian',
		component:()=>import('../views/Tuijian.vue')
		
	 },
      {
        name:'name',
        path: '/gedan',
        component: () => import('../views/Gedan.vue')
      },
	  {
	  name:'Phb',
	  path:'/Phb',
	  component:()=> import('../components/Phb.vue')
		  
	  },
	  {
	  name:'Zxyyxq',
	  path:'/Zxyyxq',
	  component:()=> import('../components/Zxyyxq.vue')
	  		  
	  },
	  {  name:'Gedanxq',
		  path:'/Gedanxq/:id',
		
		  component:()=> import('../components/Gedanxq.vue')
    },
    {
      name:'Djfsxq',
      path:'/Djfsxq',
      component:()=>import('../components/Djfsxq.vue')
    }, 

	  {
	  name:'Geshou',
	  path:'/Geshou',
	  component:()=> import('../components/Geshou.vue')
	  		  
	  },
	  {
	  name:'Geshouxq',
	  path:'/Geshouxq/:id',
	  component:()=> import('../components/Geshouxq.vue')
	  		  
    }, 
    {
      name:'/bfq',
      path:'/bfq/:id',
    component:()=>import('../components/Bfq.vue')

    }
     
	  
    ]
  },
  {
    path: '/fm',
    name: 'fm',
    component: () => import('../views/fm.vue')
  },
  
  {
    path: '/about',
    name: 'About',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "about" */ '../views/About.vue')
  }
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router
